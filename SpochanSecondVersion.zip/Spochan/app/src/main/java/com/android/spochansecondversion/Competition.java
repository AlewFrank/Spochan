package com.android.spochansecondversion;

public class Competition {

    private String competitionName;
    private String competitionData;
    private String competitionLocation;
    private String competitionDescription;
    private String competitionImageUrl;


    //правой кнопкой мыши, потом generate и дальше Constructor
    public Competition() {
    }

    public Competition(String competitionName, String competitionData, String competitionLocation, String competitionDescription) {
        this.competitionName = competitionName;
        this.competitionData = competitionData;
        this.competitionLocation = competitionLocation;
        this.competitionDescription = competitionDescription;
    }

    public String getCompetitionName() {
        return competitionName;
    }

    public void setCompetitionName(String competitionName) {
        this.competitionName = competitionName;
    }

    public String getCompetitionData() {
        return competitionData;
    }

    public void setCompetitionData(String competitionData) {
        this.competitionData = competitionData;
    }

    public String getCompetitionLocation() {
        return competitionLocation;
    }

    public void setCompetitionLocation(String competitionLocation) {
        this.competitionLocation = competitionLocation;
    }

    public String getCompetitionDescription() {
        return competitionDescription;
    }

    public void setCompetitionDescription(String competitionDescription) {
        this.competitionDescription = competitionDescription;
    }
}
