package com.android.spochansecondversion;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CompetitionAdapter extends RecyclerView.Adapter<CompetitionAdapter.CompetitionViewHolder> {//вообще не вдупляю что тут происходит, просто списывал из приложения AwesomeChat

    private ArrayList<Competition> competitions;
    private OnCompetitionClickListener listener;

    public interface OnCompetitionClickListener{
        void onCompetitionClick(int position);
    }

    public void setOnCompetitionClick(OnCompetitionClickListener listener) {
        this.listener = listener;
    }

    public CompetitionAdapter(ArrayList<Competition> competitions) {
        this.competitions = competitions;
    }

    @NonNull
    @Override
    public CompetitionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.competitions_item, parent, false);
        CompetitionViewHolder viewHolder = new CompetitionViewHolder(view, listener);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CompetitionViewHolder holder, int position) {
        /*User currentUser = users.get(position);
        holder.avatarImageView.setImageResource(currentUser.getAvatarMockUpResource());
        holder.userNameTextView.setText(currentUser.getName());*/

        Competition currentCompetition = competitions.get(position);
        holder.competitionName.setText(currentCompetition.getCompetitionName());
        holder.competitionData.setText(currentCompetition.getCompetitionData());
        holder.competitionLocation.setText(currentCompetition.getCompetitionLocation());
        holder.competitionDescription.setText(currentCompetition.getCompetitionDescription());
    }

    @Override
    public int getItemCount() {
        return competitions.size();
    }


    public class CompetitionViewHolder extends RecyclerView.ViewHolder {

        private TextView competitionName;
        private TextView competitionData;
        private TextView competitionLocation;
        private TextView competitionDescription;
        //private ImageView competitionImageView;

        public CompetitionViewHolder(@NonNull View itemView, final OnCompetitionClickListener listener) {
            super(itemView);

            competitionName = itemView.findViewById(R.id.competitionNameTextView);
            competitionData = itemView.findViewById(R.id.competitionDataTextView);
            competitionLocation = itemView.findViewById(R.id.competitionLocationTextView);
            competitionDescription = itemView.findViewById(R.id.competitionDescriptionTextView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onCompetitionClick(position);
                        }
                    }
                }
            });
        }
    }
}
