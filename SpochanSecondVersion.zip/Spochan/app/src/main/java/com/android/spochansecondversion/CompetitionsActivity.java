package com.android.spochansecondversion;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class CompetitionsActivity extends AppCompatActivity {

    private FirebaseAuth auth;

    private DatabaseReference competitionsDataBaseReference;
    private ChildEventListener competitionsChildEventListener;

    private ArrayList<Competition> competitionArrayList;
    private RecyclerView competitionRecycleView;
    private CompetitionAdapter competitionAdapter;
    private RecyclerView.LayoutManager competitionLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_competitions);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.navigation_competitions);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.navigation_rating:
                        startActivity(new Intent(getApplicationContext(), RatingActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_news:
                        startActivity(new Intent(getApplicationContext(), NewsActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_myProfile:
                        startActivity(new Intent(getApplicationContext(), MyProfileActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_competitions:
                        return true;
                }
                return false;
            }
        });


        //Все что выше это настройки для меню, которое снизу находится, а ниже этой записи остальные настройки


        auth = FirebaseAuth.getInstance();

        competitionsDataBaseReference = FirebaseDatabase.getInstance().getReference().child("Competitions");
        competitionsDataBaseReference.keepSynced(true);//автоматическая синхронизация с базой данных

        competitionRecycleView = (RecyclerView)findViewById(R.id.competitionsListRecycleView);
        competitionRecycleView.setHasFixedSize(true);
        competitionRecycleView.setLayoutManager(new LinearLayoutManager(this));

        //competitionArrayList = new ArrayList<>();

        //attachCompetitionDatabaseReferenceListener();//прикрепить листенер к датабейс референс

        //buildRecycleView();

        FloatingActionButton floatingActionButton = findViewById(R.id.addFloatingActionButton);//кнопка добавляющая нам новую запись
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Competition competition = new Competition();
                competition.setCompetitionName("Чемпионат России");
                competition.setCompetitionData("26.08.2020");
                competition.setCompetitionLocation("г. Москва");
                competition.setCompetitionDescription("Чемпионат России пройдет в городе Москве, примерное колличество участников это 35 человек, все медали как всегда получат ребята из Северного ветра, ну и другая капец важная и полезная информация");
                competitionsDataBaseReference.setValue(competition);
                //mDatabase.child("Users").child(currentUserUid).setValue(user);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();



    }

    /*private void attachCompetitionDatabaseReferenceListener() {
        competitionsDataBaseReference = FirebaseDatabase.getInstance().getReference().child("Competitions");

        if (competitionsChildEventListener == null) {//чтоб не создавать миллиард event listener, а создаем только тогда, когда он не существует
            competitionsChildEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                    Competition competition = new Competition();
                    //Competition competition = snapshot.getValue(Competition.class);
                    competition.setCompetitionName("Название соревнований");
                    competition.setCompetitionData("Дата соревнований");
                    competition.setCompetitionLocation("Место проведения соревнований");
                    competition.setCompetitionDescription("Описание соревнований");
                    competitionArrayList.add(competition);
                    competitionAdapter.notifyDataSetChanged();

                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot snapshot) {

                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            };

            competitionsDataBaseReference.addChildEventListener(competitionsChildEventListener);
        }
    }

    private void buildRecycleView() {

        competitionRecycleView = findViewById(R.id.competitionsListRecycleView);
        competitionRecycleView.setHasFixedSize(true);
        competitionLayoutManager = new LinearLayoutManager(this);
        competitionAdapter = new CompetitionAdapter(competitionArrayList);

        competitionRecycleView.setLayoutManager(competitionLayoutManager);
        competitionRecycleView.setAdapter(competitionAdapter);

        competitionAdapter.setOnCompetitionClick(new CompetitionAdapter.OnCompetitionClickListener() {//устанавливаем адаптер, а в адаптере прописан метод onClick(setOnCompetitionClick) для каждого объекта наших соревнований, все это делается для того, чтоб если нажимаешь на соревнование, то открывалось активити, где будет более развернутая информация по чемпионату
            @Override
            public void onCompetitionClick(int position) {
                goToCompetitionItem(position);//создали метод ниже
            }
        });
    }

    private void goToCompetitionItem(int position) {//нужен для того, чтоб при нажатии на конкретные соревы открывалась отдельная активити с этим соревнованием
        /*Intent intent = new Intent(UserListActivity.this, ChatActivity.class);
        intent.putExtra("recipientUserId", userArrayList.get(position).getId());//получаем айди юзера, на которого кликнули
        intent.putExtra("userName", userName);
        intent.putExtra("recipientUserName", userArrayList.get(position).getName());//это имя будет отображаться на верхней полосе, чтоб мы знали с кем ведется переписка, остальная работа с этой переменнойв в чат активити
        startActivity(intent);*/
    //}
}